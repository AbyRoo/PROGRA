<?php
require 'config.php';
if (usuario()) { header('Location: panel.php'); exit; }
$titulo = 'Diagnóstico de equipo tecnológico';
include 'header.php';
?>
<h1>Diagnóstico de equipo tecnológico</h1>
<p>Coordinación General de Tecnologías de Información · Dirección General de Servicios Telemáticos</p>
<div class="tarjetas">
  <div class="tarjeta">
    <h2>Soy solicitante</h2>
    <p>Registra tu equipo y da seguimiento a tu diagnóstico.</p>
    <a class="btn" href="login_solicitante.php">Iniciar sesión</a>
    <a class="btn sec" href="registro.php">Crear cuenta</a>
  </div>
  <div class="tarjeta">
    <h2>Soy administrador</h2>
    <p>Revisa equipos, captura el diagnóstico y sube evidencia.</p>
    <a class="btn" href="login_admin.php">Acceso administrador</a>
  </div>
</div>
<?php include 'footer.php'; ?>
