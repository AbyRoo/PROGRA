<?php $u = usuario(); ?>
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($titulo ?? 'Diagnóstico de equipo') ?></title>
<link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
<header class="barra no-print">
  <a class="marca" href="index.php">Diagnóstico de equipo tecnológico</a>
  <nav>
    <?php if ($u): ?>
      <span><?= e($u['nombre']) ?> (<?= e($u['rol']) ?>)</span>
      <a href="panel.php">Tickets</a>
      <?php if ($u['rol'] === 'administrador'): ?><a href="usuarios.php">Administradores</a><?php endif; ?>
      <a href="logout.php">Salir</a>
    <?php endif; ?>
  </nav>
</header>
<main class="contenedor">
