<?php
require 'config.php';
$u = requiere_login('solicitante');
$id = (int)($_GET['id'] ?? 0);
$campos = ['nombre_solicitante','centro_trabajo','tipo_equipo','marca','modelo','numero_serie','numero_inventario','lugar','fecha'];
$t = array_fill_keys($campos, '');
$t['nombre_solicitante'] = $u['nombre'];
$t['fecha'] = date('Y-m-d');

if ($id) {
    $st = $pdo->prepare('SELECT * FROM tickets WHERE id = ? AND solicitante_id = ?');
    $st->execute([$id, $u['id']]);
    $t = $st->fetch();
    if (!$t) { http_response_code(404); die('Ticket no encontrado.'); }
    if ($t['estado'] !== 'pendiente') die('Este ticket ya está en revisión y no se puede editar.');
}

$errores = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    foreach ($campos as $c) $t[$c] = trim($_POST[$c] ?? '');
    foreach (['nombre_solicitante','centro_trabajo','tipo_equipo','marca','modelo','lugar'] as $c) {
        if ($t[$c] === '') $errores[] = 'Falta llenar: ' . str_replace('_', ' ', $c);
    }
    $d = DateTime::createFromFormat('Y-m-d', $t['fecha']);
    if (!$d || $d->format('Y-m-d') !== $t['fecha']) $errores[] = 'Fecha inválida.';

    if (!$errores) {
        $vals = array_map(fn($c) => $t[$c] === '' ? null : $t[$c], $campos);
        if ($id) {
            $set = implode(', ', array_map(fn($c) => "$c = ?", $campos));
            $pdo->prepare("UPDATE tickets SET $set WHERE id = ? AND solicitante_id = ? AND estado = 'pendiente'")
                ->execute(array_merge($vals, [$id, $u['id']]));
        } else {
            $cols = implode(', ', $campos);
            $ph = implode(', ', array_fill(0, count($campos), '?'));
            $pdo->prepare("INSERT INTO tickets (solicitante_id, $cols) VALUES (?, $ph)")
                ->execute(array_merge([$u['id']], $vals));
            $id = (int)$pdo->lastInsertId();
        }
        header('Location: ticket_ver.php?id=' . $id); exit;
    }
}
$titulo = $id ? 'Editar ticket' : 'Nuevo ticket';
include 'header.php';
?>
<h1><?= $id ? "Editar ticket #$id" : 'Nuevo ticket' ?></h1>
<?php foreach ($errores as $er): ?><p class="error"><?= e($er) ?></p><?php endforeach; ?>
<form method="post" class="caja grid2">
  <?= csrf_campo() ?>
  <label>Nombre del solicitante <input name="nombre_solicitante" value="<?= e($t['nombre_solicitante']) ?>" required></label>
  <label>Centro de trabajo <input name="centro_trabajo" value="<?= e($t['centro_trabajo']) ?>" required></label>
  <label>Tipo de equipo <input name="tipo_equipo" placeholder="Laptop, PC, impresora…" value="<?= e($t['tipo_equipo']) ?>" required></label>
  <label>Marca <input name="marca" value="<?= e($t['marca']) ?>" required></label>
  <label>Modelo <input name="modelo" value="<?= e($t['modelo']) ?>" required></label>
  <label>Número de serie <input name="numero_serie" value="<?= e($t['numero_serie']) ?>"></label>
  <label>Número de inventario <input name="numero_inventario" value="<?= e($t['numero_inventario']) ?>"></label>
  <label>Lugar <input name="lugar" value="<?= e($t['lugar']) ?>" required></label>
  <label>Fecha <input type="date" name="fecha" value="<?= e($t['fecha']) ?>" required></label>
  <p class="nota completa">El diagnóstico lo captura únicamente el administrador.</p>
  <div class="completa">
    <button class="btn">Guardar</button>
    <a class="btn sec" href="panel.php">Cancelar</a>
  </div>
</form>
<?php include 'footer.php'; ?>
