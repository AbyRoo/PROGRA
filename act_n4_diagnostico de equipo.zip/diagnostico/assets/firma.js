document.querySelectorAll('.firma-wrap').forEach(function (wrap) {
  var c = wrap.querySelector('canvas');
  var campo = wrap.querySelector('input[type=hidden]');
  var ctx = c.getContext('2d');
  var dibujando = false, tiene = false;

  function ajustar() {
    var r = c.getBoundingClientRect();
    c.width = r.width; c.height = r.height;
    ctx.lineWidth = 2.2; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.strokeStyle = '#000';
  }
  function pos(ev) {
    var r = c.getBoundingClientRect();
    return { x: ev.clientX - r.left, y: ev.clientY - r.top };
  }
  ajustar();

  c.addEventListener('pointerdown', function (ev) {
    dibujando = true; c.setPointerCapture(ev.pointerId);
    var p = pos(ev); ctx.beginPath(); ctx.moveTo(p.x, p.y);
  });
  c.addEventListener('pointermove', function (ev) {
    if (!dibujando) return;
    var p = pos(ev); ctx.lineTo(p.x, p.y); ctx.stroke(); tiene = true;
  });
  ['pointerup', 'pointercancel', 'pointerleave'].forEach(function (n) {
    c.addEventListener(n, function () { dibujando = false; });
  });

  wrap.querySelector('.limpiar').addEventListener('click', function () {
    ctx.clearRect(0, 0, c.width, c.height); tiene = false; campo.value = '';
  });

  wrap.closest('form').addEventListener('submit', function (ev) {
    if (!tiene) { alert('Dibuja tu firma en el recuadro antes de continuar.'); ev.preventDefault(); return; }
    campo.value = c.toDataURL('image/png');
  });
});
