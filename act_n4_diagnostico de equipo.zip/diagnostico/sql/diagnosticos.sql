CREATE DATABASE IF NOT EXISTS diagnosticos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE diagnosticos;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  correo VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  rol ENUM('solicitante','administrador') NOT NULL DEFAULT 'solicitante',
  es_director TINYINT(1) NOT NULL DEFAULT 0,
  creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS tickets (
  id INT AUTO_INCREMENT PRIMARY KEY,
  solicitante_id INT NOT NULL,
  -- Parte que llena el solicitante
  nombre_solicitante VARCHAR(120) NOT NULL,
  centro_trabajo VARCHAR(150) NOT NULL,
  tipo_equipo VARCHAR(80) NOT NULL,
  marca VARCHAR(80) NOT NULL,
  modelo VARCHAR(80) NOT NULL,
  numero_serie VARCHAR(80) NULL,
  numero_inventario VARCHAR(80) NULL,
  lugar VARCHAR(120) NOT NULL,
  fecha DATE NOT NULL,
  estado ENUM('pendiente','en_revision','diagnosticado','entregado') NOT NULL DEFAULT 'pendiente',
  -- Parte que llena el administrador
  diagnostico TEXT NULL,
  especialista_id INT NULL,
  especialista_nombre VARCHAR(120) NULL,
  firma_especialista VARCHAR(255) NULL,
  fecha_firma_especialista DATETIME NULL,
  -- Vo. bo. del Director General
  director_nombre VARCHAR(120) NULL,
  firma_director VARCHAR(255) NULL,
  fecha_firma_director DATETIME NULL,
  -- Recibido
  receptor_nombre VARCHAR(120) NULL,
  firma_receptor VARCHAR(255) NULL,
  fecha_firma_receptor DATETIME NULL,
  creado TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  actualizado TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (solicitante_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  FOREIGN KEY (especialista_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS evidencias (
  id INT AUTO_INCREMENT PRIMARY KEY,
  ticket_id INT NOT NULL,
  archivo VARCHAR(255) NOT NULL,
  descripcion VARCHAR(200) NULL,
  subido_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB;
