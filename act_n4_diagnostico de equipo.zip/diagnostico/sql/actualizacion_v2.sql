-- Solo si YA importaste la versión anterior. Ejecutar en phpMyAdmin sobre la base "diagnosticos".
USE diagnosticos;
ALTER TABLE usuarios ADD COLUMN IF NOT EXISTS es_director TINYINT(1) NOT NULL DEFAULT 0 AFTER rol;
ALTER TABLE tickets  ADD COLUMN IF NOT EXISTS director_nombre VARCHAR(120) NULL AFTER fecha_firma_especialista;
ALTER TABLE tickets  ADD COLUMN IF NOT EXISTS firma_director VARCHAR(255) NULL AFTER director_nombre;
ALTER TABLE tickets  ADD COLUMN IF NOT EXISTS fecha_firma_director DATETIME NULL AFTER firma_director;
