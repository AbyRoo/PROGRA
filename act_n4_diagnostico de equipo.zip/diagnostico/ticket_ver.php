<?php
require 'config.php';
$u = requiere_login();
$admin = $u['rol'] === 'administrador';
$esDirector = $admin && !empty($u['es_director']);
$id = (int)($_GET['id'] ?? 0);

$st = $pdo->prepare('SELECT * FROM tickets WHERE id = ?');
$st->execute([$id]);
$t = $st->fetch();
if (!$t || (!$admin && $t['solicitante_id'] != $u['id'])) { http_response_code(404); die('Ticket no encontrado.'); }

$error = ''; $errorDir = '';

// El solicitante firma de recibido (solo cuando el especialista ya firmó)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$admin && $t['estado'] === 'diagnosticado') {
    csrf_validar();
    $nombre = trim($_POST['receptor_nombre'] ?? '');
    $ruta = guardar_firma($_POST['firma'] ?? '');
    if ($nombre === '' || !$ruta) {
        $error = 'Escribe tu nombre y firma en el recuadro.';
    } else {
        $pdo->prepare("UPDATE tickets SET receptor_nombre = ?, firma_receptor = ?, fecha_firma_receptor = NOW(), estado = 'entregado' WHERE id = ? AND estado = 'diagnosticado'")
            ->execute([$nombre, $ruta, $id]);
        header('Location: ticket_ver.php?id=' . $id); exit;
    }
}

// El Director General da su Vo. bo.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $esDirector && ($_POST['accion'] ?? '') === 'firmar_director'
    && in_array($t['estado'], ['diagnosticado', 'entregado'], true) && !$t['firma_director']) {
    csrf_validar();
    $ruta = guardar_firma($_POST['firma'] ?? '');
    if (!$ruta) {
        $errorDir = 'La firma no es válida.';
    } else {
        $pdo->prepare('UPDATE tickets SET director_nombre = ?, firma_director = ?, fecha_firma_director = NOW() WHERE id = ? AND firma_director IS NULL')
            ->execute([$u['nombre'], $ruta, $id]);
        header('Location: ticket_ver.php?id=' . $id); exit;
    }
}

$ev = $pdo->prepare('SELECT * FROM evidencias WHERE ticket_id = ? ORDER BY id');
$ev->execute([$id]);
$evidencias = $ev->fetchAll();

$puedeFirmarRecibido = !$admin && $t['estado'] === 'diagnosticado';
$puedeDarVobo = $esDirector && in_array($t['estado'], ['diagnosticado', 'entregado'], true) && !$t['firma_director'];

$titulo = 'Ticket #' . $id;
include 'header.php';
?>
<div class="fila no-print">
  <h1>Ticket #<?= $id ?> <span class="estado e-<?= e($t['estado']) ?>"><?= e(estado_texto($t['estado'])) ?></span></h1>
  <div>
    <button class="btn sec" onclick="window.print()">Imprimir</button>
    <?php if ($admin && in_array($t['estado'], ['pendiente', 'en_revision'])): ?>
      <a class="btn" href="ticket_revisar.php?id=<?= $id ?>">Revisar / diagnosticar</a>
    <?php endif; ?>
  </div>
</div>

<section class="formato">
  <h2>Coordinación General de Tecnologías de Información<br>Dirección General de Servicios Telemáticos</h2>
  <p class="subtitulo"><em>Diagnóstico de equipo tecnológico</em></p>

  <div class="datos">
    <p><b>Nombre del solicitante:</b> <u><?= e($t['nombre_solicitante']) ?></u></p>
    <p><b>Centro de trabajo:</b> <u><?= e($t['centro_trabajo']) ?></u></p>
    <p><b>Tipo de equipo:</b> <u><?= e($t['tipo_equipo']) ?></u></p>
    <p><b>Marca:</b> <u><?= e($t['marca']) ?></u></p>
    <p><b>Modelo:</b> <u><?= e($t['modelo']) ?></u></p>
    <p><b>Número de serie:</b> <u><?= e($t['numero_serie']) ?></u></p>
    <p><b>Número de inventario:</b> <u><?= e($t['numero_inventario']) ?></u></p>
    <p><b>Lugar y fecha:</b> <u><?= e($t['lugar']) ?>, <?= e($t['fecha']) ?></u></p>
  </div>

  <p><b>Diagnóstico:</b></p>
  <div class="diagnostico"><?= $t['diagnostico'] ? nl2br(e($t['diagnostico'])) : '<span class="nota">Aún sin diagnóstico.</span>' ?></div>

  <div class="firmas">
    <div class="firma-col">
      <div class="firma-img"><?php if ($t['firma_especialista']): ?><img src="<?= e($t['firma_especialista']) ?>" alt="Firma especialista"><?php endif; ?></div>
      <div class="linea"><?= e($t['especialista_nombre']) ?></div>
      <small>Nombre y firma del Especialista que revisó</small>
      <?php if ($t['fecha_firma_especialista']): ?><small class="nota"><?= e($t['fecha_firma_especialista']) ?></small><?php endif; ?>
    </div>
    <div class="sello">
      <img src="assets/sello.png" alt="Sello de la Dirección - Universidad de Colima">
      <span>Sello de la Dirección</span>
    </div>
    <div class="firma-col">
      <div class="firma-img"><?php if ($t['firma_director']): ?><img src="<?= e($t['firma_director']) ?>" alt="Firma del Director General"><?php endif; ?></div>
      <div class="linea">Ing. Juan Francisco Vaca Gutiérrez</div>
      <small>Vo. bo. del Director General</small>
      <?php if ($t['fecha_firma_director']): ?><small class="nota"><?= e($t['fecha_firma_director']) ?></small><?php endif; ?>
    </div>
  </div>
  <div class="firmas">
    <div class="firma-col">
      <div class="firma-img"><?php if ($t['firma_receptor']): ?><img src="<?= e($t['firma_receptor']) ?>" alt="Firma de recibido"><?php endif; ?></div>
      <div class="linea"><?= e($t['receptor_nombre']) ?></div>
      <small>Nombre y firma de la persona que recibe el diagnóstico y el equipo.</small>
      <?php if ($t['fecha_firma_receptor']): ?><small class="nota"><?= e($t['fecha_firma_receptor']) ?></small><?php endif; ?>
    </div>
  </div>
</section>

<?php if ($evidencias): ?>
<section class="caja no-print">
  <h2>Evidencia de la reparación</h2>
  <div class="galeria">
    <?php foreach ($evidencias as $f): ?>
      <figure>
        <a href="<?= e($f['archivo']) ?>" target="_blank"><img src="<?= e($f['archivo']) ?>" alt="Evidencia"></a>
        <?php if ($f['descripcion']): ?><figcaption><?= e($f['descripcion']) ?></figcaption><?php endif; ?>
      </figure>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<?php if ($puedeDarVobo): ?>
<section class="caja no-print" id="vobo">
  <h2>Vo. bo. del Director General</h2>
  <p>Firmas como <b><?= e($u['nombre']) ?></b>.</p>
  <?php if ($errorDir): ?><p class="error"><?= e($errorDir) ?></p><?php endif; ?>
  <form method="post">
    <?= csrf_campo() ?><input type="hidden" name="accion" value="firmar_director">
    <div class="firma-wrap">
      <canvas></canvas>
      <input type="hidden" name="firma">
      <button type="button" class="btn sec limpiar">Borrar firma</button>
    </div>
    <button class="btn">Firmar Vo. bo.</button>
  </form>
</section>
<?php endif; ?>

<?php if ($puedeFirmarRecibido): ?>
<section class="caja no-print">
  <h2>Firmar de recibido</h2>
  <p>Al firmar confirmas que recibiste el diagnóstico y el equipo.</p>
  <?php if ($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?>
  <form method="post">
    <?= csrf_campo() ?>
    <label>Nombre de quien recibe <input name="receptor_nombre" value="<?= e($t['nombre_solicitante']) ?>" required></label>
    <div class="firma-wrap">
      <canvas></canvas>
      <input type="hidden" name="firma">
      <button type="button" class="btn sec limpiar">Borrar firma</button>
    </div>
    <button class="btn">Firmar y confirmar recepción</button>
  </form>
</section>
<?php endif; ?>
<?php if ($puedeDarVobo || $puedeFirmarRecibido): ?><script src="assets/firma.js"></script><?php endif; ?>

<p class="no-print"><a href="panel.php">← Volver a la lista</a></p>
<?php include 'footer.php'; ?>
