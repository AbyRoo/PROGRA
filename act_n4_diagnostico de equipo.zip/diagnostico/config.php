<?php
session_start();

const DB_HOST = 'localhost';
const DB_NAME = 'diagnosticos';
const DB_USER = 'root';
const DB_PASS = '';   // XAMPP por defecto no tiene contraseña

try {
    $pdo = new PDO('mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4', DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
} catch (PDOException $ex) {
    die('No se pudo conectar a la base de datos. ¿Importaste sql/diagnosticos.sql en phpMyAdmin?');
}

function e($s) { return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

function csrf_campo() {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return '<input type="hidden" name="csrf" value="' . $_SESSION['csrf'] . '">';
}
function csrf_validar() {
    if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) {
        http_response_code(403);
        die('Token de seguridad inválido. Regresa y vuelve a intentarlo.');
    }
}

function usuario() { return $_SESSION['usuario'] ?? null; }

function requiere_login($rol = null) {
    $u = usuario();
    if (!$u) { header('Location: index.php'); exit; }
    if ($rol && $u['rol'] !== $rol) { http_response_code(403); die('Acceso denegado.'); }
    return $u;
}

function estado_texto($e) {
    return [
        'pendiente'     => 'Pendiente',
        'en_revision'   => 'En revisión',
        'diagnosticado' => 'Diagnosticado (falta recibir)',
        'entregado'     => 'Entregado',
    ][$e] ?? $e;
}

// Guarda una firma (data URL PNG del canvas) y regresa la ruta relativa, o null si no es válida
function guardar_firma($dataUrl) {
    $pre = 'data:image/png;base64,';
    if (strpos($dataUrl, $pre) !== 0) return null;
    $bin = base64_decode(substr($dataUrl, strlen($pre)), true);
    if ($bin === false || strlen($bin) > 800000) return null;
    $info = @getimagesizefromstring($bin);
    if (!$info || $info[2] !== IMAGETYPE_PNG) return null;
    $dir = __DIR__ . '/uploads/firmas';
    if (!is_dir($dir)) mkdir($dir, 0775, true);
    $nombre = bin2hex(random_bytes(16)) . '.png';
    file_put_contents("$dir/$nombre", $bin);
    return 'uploads/firmas/' . $nombre;
}

function borrar_archivo($ruta) {
    if ($ruta && strpos($ruta, 'uploads/') === 0 && strpos($ruta, '..') === false) {
        $f = __DIR__ . '/' . $ruta;
        if (is_file($f)) unlink($f);
    }
}
