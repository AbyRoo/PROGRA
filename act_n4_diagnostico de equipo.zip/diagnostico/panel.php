<?php
require 'config.php';
$u = requiere_login();
$admin = $u['rol'] === 'administrador';

$where = []; $par = [];
if (!$admin) { $where[] = 'solicitante_id = ?'; $par[] = $u['id']; }
$estado = $_GET['estado'] ?? '';
if (in_array($estado, ['pendiente','en_revision','diagnosticado','entregado'], true)) { $where[] = 'estado = ?'; $par[] = $estado; }
$q = trim($_GET['q'] ?? '');
if ($q !== '') {
    $where[] = '(nombre_solicitante LIKE ? OR numero_serie LIKE ? OR numero_inventario LIKE ? OR marca LIKE ? OR tipo_equipo LIKE ?)';
    for ($i = 0; $i < 5; $i++) $par[] = "%$q%";
}
$sql = 'SELECT * FROM tickets' . ($where ? ' WHERE ' . implode(' AND ', $where) : '') . ' ORDER BY creado DESC';
$st = $pdo->prepare($sql); $st->execute($par);
$tickets = $st->fetchAll();

$titulo = 'Tickets';
include 'header.php';
?>
<div class="fila">
  <h1><?= $admin ? 'Todos los tickets' : 'Mis tickets' ?></h1>
  <?php if (!$admin): ?><a class="btn" href="ticket_form.php">+ Nuevo ticket</a><?php endif; ?>
</div>

<form method="get" class="filtros">
  <input name="q" placeholder="Buscar solicitante, serie, inventario…" value="<?= e($q) ?>">
  <select name="estado">
    <option value="">Todos los estados</option>
    <?php foreach (['pendiente','en_revision','diagnosticado','entregado'] as $es): ?>
      <option value="<?= $es ?>" <?= $estado === $es ? 'selected' : '' ?>><?= e(estado_texto($es)) ?></option>
    <?php endforeach; ?>
  </select>
  <button class="btn sec">Filtrar</button>
</form>

<?php if (!$tickets): ?>
  <p>No hay tickets todavía.</p>
<?php else: ?>
<div class="tabla-wrap">
<table>
  <tr><th>#</th><th>Solicitante</th><th>Equipo</th><th>Serie / Inventario</th><th>Fecha</th><th>Estado</th><th>Acciones</th></tr>
  <?php foreach ($tickets as $t): ?>
  <tr>
    <td><?= $t['id'] ?></td>
    <td><?= e($t['nombre_solicitante']) ?></td>
    <td><?= e($t['tipo_equipo']) ?> <?= e($t['marca']) ?> <?= e($t['modelo']) ?></td>
    <td><?= e($t['numero_serie']) ?> / <?= e($t['numero_inventario']) ?></td>
    <td><?= e($t['fecha']) ?></td>
    <td><span class="estado e-<?= e($t['estado']) ?>"><?= e(estado_texto($t['estado'])) ?></span></td>
    <td class="acciones">
      <a href="ticket_ver.php?id=<?= $t['id'] ?>">Ver</a>
      <?php if ($admin && !empty($u['es_director']) && in_array($t['estado'], ['diagnosticado','entregado']) && !$t['firma_director']): ?>
        <a href="ticket_ver.php?id=<?= $t['id'] ?>#vobo"><b>Dar Vo. bo.</b></a>
      <?php endif; ?>
      <?php if ($admin && $t['estado'] !== 'entregado' && $t['estado'] !== 'diagnosticado'): ?>
        <a href="ticket_revisar.php?id=<?= $t['id'] ?>">Revisar</a>
      <?php endif; ?>
      <?php if (!$admin && $t['estado'] === 'pendiente'): ?>
        <a href="ticket_form.php?id=<?= $t['id'] ?>">Editar</a>
      <?php endif; ?>
      <?php if ($admin || $t['estado'] === 'pendiente'): ?>
        <form method="post" action="ticket_eliminar.php" onsubmit="return confirm('¿Eliminar el ticket #<?= $t['id'] ?>? No se puede deshacer.')">
          <?= csrf_campo() ?><input type="hidden" name="id" value="<?= $t['id'] ?>">
          <button class="link peligro">Eliminar</button>
        </form>
      <?php endif; ?>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php endif; ?>
<?php include 'footer.php'; ?>
