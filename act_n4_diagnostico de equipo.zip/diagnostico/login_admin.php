<?php
$rol = "administrador";
require "_login.php";
