<?php
// Crea el primer administrador. BÓRRALO después de usarlo.
require 'config.php';
$hay = $pdo->query("SELECT COUNT(*) FROM usuarios WHERE rol='administrador'")->fetchColumn() > 0;
$msg = '';
if (!$hay && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $n = trim($_POST['nombre'] ?? ''); $c = trim($_POST['correo'] ?? ''); $p = $_POST['password'] ?? '';
    if ($n && filter_var($c, FILTER_VALIDATE_EMAIL) && strlen($p) >= 8) {
        $pdo->prepare('INSERT INTO usuarios (nombre, correo, password_hash, rol, es_director) VALUES (?,?,?,"administrador",?)')
            ->execute([$n, $c, password_hash($p, PASSWORD_DEFAULT), isset($_POST['es_director']) ? 1 : 0]);
        $hay = true;
        $msg = 'Administrador creado. Ahora BORRA el archivo install.php.';
    } else {
        $msg = 'Revisa los datos (contraseña de mínimo 8 caracteres).';
    }
}
$titulo = 'Instalación';
include 'header.php';
?>
<div class="caja angosta">
  <h1>Crear administrador</h1>
  <?php if ($msg): ?><p class="ok"><?= e($msg) ?></p><?php endif; ?>
  <?php if ($hay): ?>
    <p>Ya existe un administrador. Elimina este archivo (<code>install.php</code>).</p>
  <?php else: ?>
  <form method="post">
    <?= csrf_campo() ?>
    <label>Nombre <input name="nombre" required></label>
    <label>Correo <input type="email" name="correo" required></label>
    <label>Contraseña <input type="password" name="password" required></label>
    <label class="check"><input type="checkbox" name="es_director"> Esta cuenta es del Director General (Ing. Juan Francisco Vaca Gutiérrez)</label>
    <button class="btn">Crear</button>
  </form>
  <?php endif; ?>
</div>
<?php include 'footer.php'; ?>
