<?php
require 'config.php';
$error = '';
$nombre = $correo = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $nombre = trim($_POST['nombre'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $pass   = $_POST['password'] ?? '';
    if ($nombre === '' || !filter_var($correo, FILTER_VALIDATE_EMAIL)) {
        $error = 'Escribe tu nombre y un correo válido.';
    } elseif (strlen($pass) < 8) {
        $error = 'La contraseña debe tener al menos 8 caracteres.';
    } else {
        $st = $pdo->prepare('SELECT id FROM usuarios WHERE correo = ?');
        $st->execute([$correo]);
        if ($st->fetch()) {
            $error = 'Ese correo ya está registrado.';
        } else {
            $pdo->prepare('INSERT INTO usuarios (nombre, correo, password_hash, rol) VALUES (?,?,?,"solicitante")')
                ->execute([$nombre, $correo, password_hash($pass, PASSWORD_DEFAULT)]);
            header('Location: login_solicitante.php'); exit;
        }
    }
}
$titulo = 'Crear cuenta';
include 'header.php';
?>
<div class="caja angosta">
  <h1>Crear cuenta de solicitante</h1>
  <?php if ($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?>
  <form method="post">
    <?= csrf_campo() ?>
    <label>Nombre completo <input name="nombre" value="<?= e($nombre) ?>" required></label>
    <label>Correo <input type="email" name="correo" value="<?= e($correo) ?>" required></label>
    <label>Contraseña (mín. 8 caracteres) <input type="password" name="password" required></label>
    <button class="btn">Registrarme</button>
  </form>
  <p><a href="index.php">← Volver</a></p>
</div>
<?php include 'footer.php'; ?>
