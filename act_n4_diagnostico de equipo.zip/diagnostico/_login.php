<?php
// Lógica compartida; cada página define $rol antes de incluir este archivo
require 'config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $st = $pdo->prepare('SELECT * FROM usuarios WHERE correo = ? AND rol = ?');
    $st->execute([trim($_POST['correo'] ?? ''), $rol]);
    $usr = $st->fetch();
    if ($usr && password_verify($_POST['password'] ?? '', $usr['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['usuario'] = ['id' => $usr['id'], 'nombre' => $usr['nombre'], 'rol' => $usr['rol'], 'es_director' => (int)$usr['es_director']];
        header('Location: panel.php'); exit;
    }
    $error = 'Correo o contraseña incorrectos.';
}
$titulo = $rol === 'administrador' ? 'Acceso administrador' : 'Acceso solicitante';
include 'header.php';
?>
<div class="caja angosta">
  <h1><?= e($titulo) ?></h1>
  <?php if ($error): ?><p class="error"><?= e($error) ?></p><?php endif; ?>
  <form method="post">
    <?= csrf_campo() ?>
    <label>Correo <input type="email" name="correo" required autofocus></label>
    <label>Contraseña <input type="password" name="password" required></label>
    <button class="btn">Entrar</button>
  </form>
  <?php if ($rol === 'solicitante'): ?>
    <p>¿No tienes cuenta? <a href="registro.php">Regístrate</a></p>
  <?php endif; ?>
  <p><a href="index.php">← Volver</a></p>
</div>
<?php include 'footer.php'; ?>
