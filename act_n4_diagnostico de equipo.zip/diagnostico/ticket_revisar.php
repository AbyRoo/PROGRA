<?php
require 'config.php';
$u = requiere_login('administrador');
$id = (int)($_GET['id'] ?? 0);

function cargar($pdo, $id) {
    $st = $pdo->prepare('SELECT * FROM tickets WHERE id = ?'); $st->execute([$id]);
    return $st->fetch();
}
$t = cargar($pdo, $id);
if (!$t) { http_response_code(404); die('Ticket no encontrado.'); }

$msg = ''; $err = '';
$bloqueado = in_array($t['estado'], ['diagnosticado', 'entregado'], true);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $accion = $_POST['accion'] ?? '';
    if ($bloqueado) {
        $err = 'Este ticket ya fue firmado por el especialista y no se puede modificar.';
    } elseif ($accion === 'guardar') {
        $pdo->prepare("UPDATE tickets SET diagnostico = ?, estado = 'en_revision', especialista_id = ? WHERE id = ?")
            ->execute([trim($_POST['diagnostico'] ?? ''), $u['id'], $id]);
        $msg = 'Diagnóstico guardado.';
    } elseif ($accion === 'evidencia') {
        $f = $_FILES['fotos'] ?? null;
        $desc = trim($_POST['descripcion'] ?? '') ?: null;
        $tipos = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
        $n = 0;
        if ($f && is_array($f['name'])) {
            foreach ($f['name'] as $i => $nombreOrig) {
                if ($f['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
                if ($f['error'][$i] !== UPLOAD_ERR_OK || $f['size'][$i] > 5 * 1024 * 1024) {
                    $err .= "«$nombreOrig» no se pudo subir (máx. 5 MB). "; continue;
                }
                $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name'][$i]);
                if (!isset($tipos[$mime])) { $err .= "«$nombreOrig» no es JPG, PNG o WEBP. "; continue; }
                $dir = __DIR__ . '/uploads/evidencias';
                if (!is_dir($dir)) mkdir($dir, 0775, true);
                $nombre = bin2hex(random_bytes(16)) . '.' . $tipos[$mime];
                if (move_uploaded_file($f['tmp_name'][$i], "$dir/$nombre")) {
                    $pdo->prepare('INSERT INTO evidencias (ticket_id, archivo, descripcion) VALUES (?,?,?)')
                        ->execute([$id, 'uploads/evidencias/' . $nombre, $desc]);
                    $n++;
                }
            }
        }
        if ($n) {
            $msg = "$n foto(s) subida(s).";
            $pdo->prepare("UPDATE tickets SET estado = 'en_revision', especialista_id = ? WHERE id = ?")->execute([$u['id'], $id]);
        } elseif (!$err) { $err = 'Selecciona al menos una foto.'; }
    } elseif ($accion === 'quitar_evidencia') {
        $st = $pdo->prepare('SELECT * FROM evidencias WHERE id = ? AND ticket_id = ?');
        $st->execute([(int)($_POST['evidencia_id'] ?? 0), $id]);
        if ($ev = $st->fetch()) {
            borrar_archivo($ev['archivo']);
            $pdo->prepare('DELETE FROM evidencias WHERE id = ?')->execute([$ev['id']]);
            $msg = 'Evidencia eliminada.';
        }
    } elseif ($accion === 'firmar') {
        $t = cargar($pdo, $id);
        $nEv = $pdo->prepare('SELECT COUNT(*) FROM evidencias WHERE ticket_id = ?'); $nEv->execute([$id]);
        $ruta = guardar_firma($_POST['firma'] ?? '');
        if (trim((string)$t['diagnostico']) === '') $err = 'Guarda primero el diagnóstico.';
        elseif ($nEv->fetchColumn() < 1) $err = 'Sube al menos una foto de evidencia antes de firmar.';
        elseif (!$ruta) $err = 'La firma no es válida.';
        else {
            $pdo->prepare("UPDATE tickets SET especialista_id = ?, especialista_nombre = ?, firma_especialista = ?, fecha_firma_especialista = NOW(), estado = 'diagnosticado' WHERE id = ?")
                ->execute([$u['id'], $u['nombre'], $ruta, $id]);
            header('Location: ticket_ver.php?id=' . $id); exit;
        }
    }
    $t = cargar($pdo, $id);
}
$ev = $pdo->prepare('SELECT * FROM evidencias WHERE ticket_id = ? ORDER BY id');
$ev->execute([$id]);
$evidencias = $ev->fetchAll();

$titulo = 'Revisar ticket #' . $id;
include 'header.php';
?>
<h1>Revisar ticket #<?= $id ?> <span class="estado e-<?= e($t['estado']) ?>"><?= e(estado_texto($t['estado'])) ?></span></h1>
<?php if ($msg): ?><p class="ok"><?= e($msg) ?></p><?php endif; ?>
<?php if ($err): ?><p class="error"><?= e($err) ?></p><?php endif; ?>

<section class="caja">
  <h2>Datos del solicitante</h2>
  <div class="datos">
    <p><b>Solicitante:</b> <?= e($t['nombre_solicitante']) ?></p>
    <p><b>Centro de trabajo:</b> <?= e($t['centro_trabajo']) ?></p>
    <p><b>Equipo:</b> <?= e($t['tipo_equipo']) ?> · <?= e($t['marca']) ?> · <?= e($t['modelo']) ?></p>
    <p><b>Serie:</b> <?= e($t['numero_serie']) ?> · <b>Inventario:</b> <?= e($t['numero_inventario']) ?></p>
    <p><b>Lugar y fecha:</b> <?= e($t['lugar']) ?>, <?= e($t['fecha']) ?></p>
  </div>
</section>

<?php if ($bloqueado): ?>
  <p class="nota">Este ticket ya está firmado. <a href="ticket_ver.php?id=<?= $id ?>">Ver formato completo</a></p>
<?php else: ?>

<section class="caja">
  <h2>1. Diagnóstico</h2>
  <form method="post">
    <?= csrf_campo() ?><input type="hidden" name="accion" value="guardar">
    <textarea name="diagnostico" rows="6" placeholder="Describe el diagnóstico y la reparación realizada…"><?= e($t['diagnostico']) ?></textarea>
    <button class="btn">Guardar diagnóstico</button>
  </form>
</section>

<section class="caja">
  <h2>2. Evidencia de la reparación</h2>
  <form method="post" enctype="multipart/form-data">
    <?= csrf_campo() ?><input type="hidden" name="accion" value="evidencia">
    <label>Fotos (JPG, PNG o WEBP, máx. 5 MB c/u)
      <input type="file" name="fotos[]" accept="image/jpeg,image/png,image/webp" multiple required></label>
    <label>Descripción (opcional) <input name="descripcion" maxlength="200"></label>
    <button class="btn">Subir</button>
  </form>
  <div class="galeria">
    <?php foreach ($evidencias as $f): ?>
      <figure>
        <a href="<?= e($f['archivo']) ?>" target="_blank"><img src="<?= e($f['archivo']) ?>" alt="Evidencia"></a>
        <?php if ($f['descripcion']): ?><figcaption><?= e($f['descripcion']) ?></figcaption><?php endif; ?>
        <form method="post" onsubmit="return confirm('¿Quitar esta foto?')">
          <?= csrf_campo() ?><input type="hidden" name="accion" value="quitar_evidencia">
          <input type="hidden" name="evidencia_id" value="<?= $f['id'] ?>">
          <button class="link peligro">Quitar</button>
        </form>
      </figure>
    <?php endforeach; ?>
  </div>
</section>

<section class="caja">
  <h2>3. Firma del especialista</h2>
  <p>Firmas como <b><?= e($u['nombre']) ?></b>. Al firmar, el diagnóstico queda cerrado y el solicitante podrá firmar de recibido.</p>
  <form method="post">
    <?= csrf_campo() ?><input type="hidden" name="accion" value="firmar">
    <div class="firma-wrap">
      <canvas></canvas>
      <input type="hidden" name="firma">
      <button type="button" class="btn sec limpiar">Borrar firma</button>
    </div>
    <button class="btn">Firmar y cerrar diagnóstico</button>
  </form>
</section>
<script src="assets/firma.js"></script>
<?php endif; ?>

<p><a href="panel.php">← Volver a la lista</a></p>
<?php include 'footer.php'; ?>
