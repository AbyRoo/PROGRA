<?php
require 'config.php';
$u = requiere_login();
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: panel.php'); exit; }
csrf_validar();
$id = (int)($_POST['id'] ?? 0);

$st = $pdo->prepare('SELECT * FROM tickets WHERE id = ?');
$st->execute([$id]);
$t = $st->fetch();
if (!$t) { header('Location: panel.php'); exit; }

$admin = $u['rol'] === 'administrador';
$propio = $t['solicitante_id'] == $u['id'] && $t['estado'] === 'pendiente';
if (!$admin && !$propio) { http_response_code(403); die('No puedes eliminar este ticket.'); }

$ev = $pdo->prepare('SELECT archivo FROM evidencias WHERE ticket_id = ?');
$ev->execute([$id]);
foreach ($ev->fetchAll() as $f) borrar_archivo($f['archivo']);
borrar_archivo($t['firma_especialista']);
borrar_archivo($t['firma_receptor']);

$pdo->prepare('DELETE FROM tickets WHERE id = ?')->execute([$id]);
header('Location: panel.php'); exit;
