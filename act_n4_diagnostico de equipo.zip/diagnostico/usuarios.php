<?php
require 'config.php';
$u = requiere_login('administrador');
$msg = ''; $err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_validar();
    $accion = $_POST['accion'] ?? '';
    if ($accion === 'crear') {
        $n = trim($_POST['nombre'] ?? ''); $c = trim($_POST['correo'] ?? ''); $p = $_POST['password'] ?? '';
        $dir = isset($_POST['es_director']) ? 1 : 0;
        $ya = $pdo->prepare('SELECT id FROM usuarios WHERE correo = ?'); $ya->execute([$c]);
        if ($n === '' || !filter_var($c, FILTER_VALIDATE_EMAIL) || strlen($p) < 8) $err = 'Revisa los datos (contraseña de mínimo 8 caracteres).';
        elseif ($ya->fetch()) $err = 'Ese correo ya está registrado.';
        else {
            $pdo->beginTransaction();
            if ($dir) $pdo->exec('UPDATE usuarios SET es_director = 0');
            $pdo->prepare('INSERT INTO usuarios (nombre, correo, password_hash, rol, es_director) VALUES (?,?,?,"administrador",?)')
                ->execute([$n, $c, password_hash($p, PASSWORD_DEFAULT), $dir]);
            $pdo->commit();
            if ($dir) $_SESSION['usuario']['es_director'] = 0;
            $msg = 'Administrador creado.';
        }
    } elseif ($accion === 'director' || $accion === 'quitar_director') {
        $id = (int)($_POST['id'] ?? 0);
        $pdo->beginTransaction();
        $pdo->exec('UPDATE usuarios SET es_director = 0');
        if ($accion === 'director') $pdo->prepare("UPDATE usuarios SET es_director = 1 WHERE id = ? AND rol = 'administrador'")->execute([$id]);
        $pdo->commit();
        $_SESSION['usuario']['es_director'] = ($accion === 'director' && $id == $u['id']) ? 1 : 0;
        $msg = 'Director General actualizado.';
    }
}
$u = usuario();
$admins = $pdo->query("SELECT id, nombre, correo, es_director FROM usuarios WHERE rol = 'administrador' ORDER BY nombre")->fetchAll();
$titulo = 'Administradores';
include 'header.php';
?>
<h1>Administradores</h1>
<?php if ($msg): ?><p class="ok"><?= e($msg) ?></p><?php endif; ?>
<?php if ($err): ?><p class="error"><?= e($err) ?></p><?php endif; ?>
<p class="nota">La cuenta marcada como Director General puede dar el Vo. bo. (firma) en los tickets y también puede revisar equipos como cualquier administrador.</p>

<div class="tabla-wrap"><table>
  <tr><th>Nombre</th><th>Correo</th><th>Director General</th><th></th></tr>
  <?php foreach ($admins as $a): ?>
  <tr>
    <td><?= e($a['nombre']) ?></td><td><?= e($a['correo']) ?></td>
    <td><?= $a['es_director'] ? '✦ Sí' : 'No' ?></td>
    <td>
      <form method="post" style="margin:0">
        <?= csrf_campo() ?><input type="hidden" name="id" value="<?= $a['id'] ?>">
        <?php if ($a['es_director']): ?>
          <input type="hidden" name="accion" value="quitar_director"><button class="link">Quitar como Director</button>
        <?php else: ?>
          <input type="hidden" name="accion" value="director"><button class="link">Marcar como Director</button>
        <?php endif; ?>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table></div>

<section class="caja angosta">
  <h2>Nuevo administrador</h2>
  <form method="post">
    <?= csrf_campo() ?><input type="hidden" name="accion" value="crear">
    <label>Nombre <input name="nombre" required></label>
    <label>Correo <input type="email" name="correo" required></label>
    <label>Contraseña (mín. 8) <input type="password" name="password" required></label>
    <label class="check"><input type="checkbox" name="es_director"> Es el Director General (Ing. Juan Francisco Vaca Gutiérrez)</label>
    <button class="btn">Crear administrador</button>
  </form>
</section>
<?php include 'footer.php'; ?>
